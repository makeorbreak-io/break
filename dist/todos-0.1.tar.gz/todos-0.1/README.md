<p align="center">
  <img src="https://github.com/portosummerofcode/break/blob/master/logo.png" width="300">
</p>


# What is it?
TODOS is a tool designed to simplify developers work. In short, it puts all the annotations you make in your code in one place. You can see all your TODOs, FIXEMEs or any other tags you want to use listed in either a text file, GitHub issues or Trello cards. But it's always possible to extend it's functionalities to other platforms. TODOS works now in the command line and Visual Studio Code (but easy to extend to other editors) and will analyse your code and organize your annotations everytime you save your work.

<br><br>

# How to use?
First you have to download/clone this project into your projects folder???
<br>

To run the tool on the command line you have to use the following commands:

1. ???




To use TODOS in Visual Studio Code you only need to save your work to update your tasks.

<br><br>

# License

The MIT License.

<br><br>

# Authors

<table>
  <tr>
    <td>
      <img src="https://avatars1.githubusercontent.com/u/15276733?v=4&s=400" width="100">
    </td>
    <td>
      João Silva<br />
      <a href="mailto:kontakt@wojtekmaj.pl">j.pedro004@gmail.com</a><br />
    </td>
  </tr>
</table>

<table>
  <tr>
    <td>
      <img src="https://avatars3.githubusercontent.com/u/12536106?v=4&s=400" width="100">
    </td>
    <td>
      José Martins<br />
      <a href="mailto:kontakt@wojtekmaj.pl">lluismmartins7@gmail.com</a><br />
    </td>
  </tr>
</table>

<table>
  <tr>
    <td>
      <img src="https://avatars0.githubusercontent.com/u/17434192?v=4&s=400" width="100">
    </td>
    <td>
      Margarida Viterbo<br />
      <a href="mailto:kontakt@wojtekmaj.pl">margaridaviterbo@hotmail.com</a><br />
    </td>
  </tr>
</table>

<table>
  <tr>
    <td>
      <img src="https://avatars0.githubusercontent.com/u/17434192?v=4&s=400" width="100">
    </td>
    <td>
      Rui Carvalho<br />
      <a href="mailto:kontakt@wojtekmaj.pl">margaridaviterbo@hotmail.com</a><br />
    </td>
  </tr>
</table>

 
